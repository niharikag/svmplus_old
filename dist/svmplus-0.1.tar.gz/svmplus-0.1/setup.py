from setuptools import setup

setup(
    name='svmplus',
    version='0.1',
    packages=['svmplus'],
    url='',
    license='',
    author='niharika',
    author_email='niharika.gauraha@farmbio.uu.se',
    description='Implementation of SVM+'
)
