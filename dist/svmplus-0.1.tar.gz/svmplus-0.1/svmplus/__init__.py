"""
The :mod:`svmplus` module includes SVM plus algorithms.
"""

# See http://scikit-learn.sourceforge.net/modules/svm.html for complete
# documentation.

# Authors: Niharika Gauraha<niharika.gauraha@farmbio.uu.se>
#         Ola Spjuth<ola.spjuth@farmbio.uu.se>
# License:

__all__ = ['svmplus', 'libsvmplus', 'gridSearchCV']